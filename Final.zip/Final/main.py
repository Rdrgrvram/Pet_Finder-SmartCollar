# ════════════════════════════════════════════════════════════════════
#  PetFinder Smart Collar — Script principal MicroPython
#  Hardware : ESP32 DevKit V1 (38 pines)
#             NTC 10K   → GPIO 36 / VP  (divisor de voltaje con R 10K a GND)
#             SW-520D   → GPIO 18       (sensor de vibración)
#             Buzzer    → GPIO 19       (vía transistor NPN 2N2222A + R 2K)
#             GPS NEO-M8L → UART2 TX=GPIO17 RX=GPIO16 @ 9600
#  Protocolo: WiFi → Supabase REST API (HTTPS)
#  Autor    : PetFinder Team
#
#  ⚠️  ADVERTENCIA DE HARDWARE:
#  Este script está configurado para ESP32 DevKit V1 (38 pines).
#  Si usas ESP32-C3 Super Mini los pines SON DIFERENTES:
#    NTC ADC  → GPIO0  (no GPIO36, el C3 no tiene VP)
#    SW-520D  → GPIO6  (no GPIO18)
#    Buzzer   → GPIO7  (no GPIO19)
#    LED      → GPIO8  (no GPIO2)
#    GPS UART → UART(1, tx=4, rx=5)   (no UART2 — el C3 solo tiene UART0 y UART1)
#  Además UART(2,...) lanzará excepción en el C3. Ajusta según tu placa.
# ════════════════════════════════════════════════════════════════════

import network, urequests, ujson, time, machine, math, gc
from machine import Pin, UART, ADC

print("Iniciando componentes...")
time.sleep(2)

# ── Credenciales WiFi y Supabase ────────────────────────────────────
WIFI_SSID         = "ENTEL_HOGAR_2.4G"
WIFI_PASSWORD     = "123456789"
SUPABASE_URL      = "https://kjuoamogxpplpyaseeat.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtqdW9hbW9neHBwbHB5YXNlZWF0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY3OTU1NDUsImV4cCI6MjA5MjM3MTU0NX0.ty8SNcnELPCKk43qoRJft4-8IVQz6GrSouoX4T188CQ"
TABLA_LECTURAS    = "lecturas_collar"
TABLA_COMANDOS    = "comandos"
INTERVALO_CICLO   = 10

# ── Constantes NTC 10K (Beta) ────────────────────────────────────────
NTC_BETA          = 3950
NTC_R_NOMINAL     = 10000
NTC_T_NOMINAL     = 25
NTC_R_SERIE       = 10000
ADC_RESOLUCION    = 4095
ADC_VREF          = 3.3

# ── Pines ────────────────────────────────────────────────────────────
led    = Pin(2, Pin.OUT)          # LED integrado del DevKit V1
buzzer = Pin(19, Pin.OUT)         # GPIO 19 → resistencia 2K → base transistor
vibra  = Pin(18, Pin.IN, Pin.PULL_UP)  # SW-520D en GPIO 18

# NTC 10K en GPIO 36 (VP) — pin ADC de solo entrada, sin PULL
adc_ntc = ADC(Pin(36))
adc_ntc.atten(ADC.ATTN_11DB)     # Rango 0–3.6V
adc_ntc.width(ADC.WIDTH_12BIT)   # Resolución 12 bits (0–4095)

# GPS NEO-M8L en UART2 — TX=GPIO17, RX=GPIO16
# IMPORTANTE: GPS TX → GPIO16 (RX del ESP32)
#             GPS RX → GPIO17 (TX del ESP32)
# BUG FIX: baudrate era 115200 pero el NEO-M8L usa 9600 por defecto.
#          Con 115200 el ESP32 recibía basura y nunca obtenía fix válido.
gps = UART(2, baudrate=115200, tx=17, rx=16)

wlan = network.WLAN(network.STA_IF)


# ════════════════════════════════════════════════════════════════════
#  UTILIDADES
# ════════════════════════════════════════════════════════════════════

def blink(n=1, ms=100):
    for _ in range(n):
        led.value(1); time.sleep_ms(ms)
        led.value(0); time.sleep_ms(ms)


def activar_buzzer(segundos=1):
    print(f"[BUZZER] Activando por {segundos}s")
    buzzer.value(1)
    time.sleep(segundos)
    buzzer.value(0)
    print("[BUZZER] Apagado")


# ════════════════════════════════════════════════════════════════════
#  CONECTIVIDAD WiFi
# ════════════════════════════════════════════════════════════════════

def conectar_wifi():
    if wlan.isconnected():
        return True

    print(f"[WiFi] Conectando a '{WIFI_SSID}'...")

    for intento in range(5):
        wlan.active(False)
        time.sleep(2)
        wlan.active(True)
        time.sleep(2)

        wlan.config(reconnects=0)
        wlan.connect(WIFI_SSID, WIFI_PASSWORD)

        for i in range(15):
            if wlan.isconnected():
                print("[WiFi] Conectado →", wlan.ifconfig()[0])
                blink(3)
                return True
            time.sleep(1)

        print(f"[WiFi] Intento {intento+1}/5 fallido, reintentando...")
        wlan.active(False)
        time.sleep(1)

    print("[WiFi] Sin conexión tras 5 intentos.")
    return False


# ════════════════════════════════════════════════════════════════════
#  LECTURA DE SENSORES
# ════════════════════════════════════════════════════════════════════

def leer_temperatura():
    """
    Lee el NTC 10K mediante el divisor de voltaje:
        3.3V ── NTC ── GPIO36(VP) ── R10K ── GND
    Convierte el valor ADC a temperatura usando la ecuación Beta del NTC.
    """
    try:
        # Promedio de 10 lecturas para reducir ruido
        muestras = [adc_ntc.read() for _ in range(10)]
        raw = sum(muestras) // len(muestras)

        if raw <= 0 or raw >= ADC_RESOLUCION:
            print("[TEMP] Lectura ADC fuera de rango — verifica cableado")
            return None

        # R_ntc = R_serie * (ADC_max / raw - 1)
        r_ntc = NTC_R_SERIE * (ADC_RESOLUCION / raw - 1)

        # Ecuación Beta de Steinhart-Hart simplificada
        t0_kelvin   = NTC_T_NOMINAL + 273.15
        temp_kelvin = 1.0 / (1.0 / t0_kelvin + math.log(r_ntc / NTC_R_NOMINAL) / NTC_BETA)
        temp_celsius = round(temp_kelvin - 273.15, 1)

        print(f"[TEMP] ADC={raw}  R_NTC={int(r_ntc)}Ω  Temp={temp_celsius}°C")
        return temp_celsius

    except Exception as e:
        print(f"[TEMP] Error: {e}")
        return None

def detectar_movimiento(duracion_ms=2000):
    inicio = time.ticks_ms()
    cambios = 0
    ultimo = vibra.value()

    while time.ticks_diff(time.ticks_ms(), inicio) < duracion_ms:
        actual = vibra.value()

        if actual != ultimo:
            cambios += 1
            ultimo = actual

        time.sleep_ms(10)

    print("Cambios:", cambios)

    return 1 if cambios >= 2 else 0


def _convertir_coordenada(raw, direccion):
    """
    Convierte coordenada NMEA a decimal.
    BUG FIX: La version anterior usaba len(raw)>7 para decidir 2 o 3
    digitos de grados, lo cual fallaba: latitudes como "1234.5678"
    tienen 9 chars y tomaba int("123")=123 grados (imposible).
    La forma correcta es la direccion: N/S=latitud (DD), E/W=longitud (DDD).
    """
    if not raw:
        return None
    if direccion in ("N", "S"):      # Latitud NMEA: DDMM.MMMM
        g = int(raw[:2])
        m = float(raw[2:])
    else:                            # Longitud NMEA: DDDMM.MMMM
        g = int(raw[:3])
        m = float(raw[3:])
    decimal = g + m / 60.0
    if direccion in ("S", "W"):
        decimal = -decimal
    return round(decimal, 6)


def leer_gps(timeout_ms=8000):
    # 1. Limpiar datos viejos o basura acumulados en la UART mientras se leían otros sensores
    if gps.any():
        gps.read() 
        
    inicio = time.ticks_ms()
    buf = b""
    
    while time.ticks_diff(time.ticks_ms(), inicio) < timeout_ms:
        if gps.any():
            buf += gps.read()
            while b"\n" in buf:
                linea, buf = buf.split(b"\n", 1)
                try:
                    # 'ignore' evita que el script falle por caracteres extraños en el aire
                    txt = linea.decode('ascii', 'ignore').strip() 
                    
                    if txt.startswith("$GPRMC") or txt.startswith("$GNRMC"):
                        partes = txt.split(",")
                        if len(partes) > 6 and partes[2] == "A":
                            lat = _convertir_coordenada(partes[3], partes[4])
                            lon = _convertir_coordenada(partes[5], partes[6])
                            print(f"[GPS] Fix OK → lat={lat}  lon={lon}")
                            return lat, lon
                        else:
                            # Esto te avisará en consola si el GPS habla pero no tiene satélites aún
                            print("[GPS] Trama recibida, pero aún SIN FIX (Buscando satélites...)")
                except Exception as e:
                    pass
        time.sleep_ms(20) # Menor delay para no perder ráfagas de datos de la UART
        
    print("[GPS] Sin fix en el timeout (No se detectó señal válida)")
    return None, None


# ════════════════════════════════════════════════════════════════════
#  COMUNICACIÓN CON SUPABASE
# ════════════════════════════════════════════════════════════════════

def _headers_supabase():
    return {
        "apikey":        SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {SUPABASE_ANON_KEY}",
        "Content-Type":  "application/json"
    }


def enviar_lectura(temp, mov, lat, lon):
    url  = f"{SUPABASE_URL}/rest/v1/{TABLA_LECTURAS}"
    data = {"movimiento": bool(mov)}
    if temp is not None: data["temperatura"] = temp
    if lat  is not None: data["latitud"]     = lat
    if lon  is not None: data["longitud"]    = lon
    try:
        r = urequests.post(url, headers=_headers_supabase(),
                           data=ujson.dumps(data))
        print(f"[HTTP] Lectura enviada → {r.status_code}")
        if r.status_code not in (200, 201):
            try: print(f"[HTTP] Detalle: {r.text}")
            except: pass
        r.close()
        gc.collect()
        if r.status_code in (200, 201):
            blink(1)
    except Exception as e:
        print(f"[HTTP] Error: {e}")


def consultar_comando_buzzer():
    url = (f"{SUPABASE_URL}/rest/v1/{TABLA_COMANDOS}"
           f"?ejecutado=eq.false&order=created_at.desc&limit=1")
    try:
        r     = urequests.get(url, headers=_headers_supabase())
        datos = ujson.loads(r.text)
        r.close()
        gc.collect()
        if datos:
            comando = datos[0]
            id_cmd  = comando.get("id")
            accion  = comando.get("accion", "")
            print(f"[CMD] Recibido: {accion} (id={id_cmd})")
            if accion == "buzzer_on":
                activar_buzzer(3)
            elif accion == "buzzer_off":   # FIX: comando de apagado ignorado antes
                buzzer.value(0)
                print("[CMD] Buzzer apagado por comando remoto")
            _marcar_ejecutado(id_cmd)
    except Exception as e:
        print(f"[CMD] Error: {e}")


def _marcar_ejecutado(id_cmd):
    url  = f"{SUPABASE_URL}/rest/v1/{TABLA_COMANDOS}?id=eq.{id_cmd}"
    hdrs = _headers_supabase()
    hdrs["Prefer"] = "return=minimal"
    try:
        r = urequests.patch(url, headers=hdrs,
                            data=ujson.dumps({"ejecutado": True}))
        r.close()
        gc.collect()
        print(f"[CMD] Comando {id_cmd} marcado como ejecutado")
    except Exception as e:
        print(f"[CMD] Error: {e}")


# ════════════════════════════════════════════════════════════════════
#  BUCLE PRINCIPAL
# ════════════════════════════════════════════════════════════════════

def main():
    print("=" * 50)
    print("  PetFinder Smart Collar — Iniciando...")
    print("=" * 50)
    blink(3)

    conectar_wifi()

    while True:
        print("\n─── NUEVO CICLO ───────────────────────────")

        mov      = detectar_movimiento(2000)
        temp     = leer_temperatura()
        lat, lon = leer_gps(8000)

        print(f"[DATA] temp={temp}°C  mov={mov}  lat={lat}  lon={lon}")

        if not wlan.isconnected():
            print("[WiFi] Reconectando...")
            conectar_wifi()

        if wlan.isconnected():
            enviar_lectura(temp, mov, lat, lon)
            consultar_comando_buzzer()

        time.sleep(INTERVALO_CICLO)


try:
    main()
except Exception as e:
    print(f"[ERROR CRÍTICO] {e}")
    time.sleep(5)
    machine.reset()