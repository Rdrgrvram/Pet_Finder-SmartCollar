# ════════════════════════════════════════════════════════════════════
#  PetFinder Smart Collar — Script principal MicroPython
#  Hardware : ESP32-C3  |  GPS NEO-M8L  |  PIR  |  Buzzer activo
#  Protocolo: WiFi → Supabase REST API (HTTPS)
#  Autor    : PetFinder Team
# ════════════════════════════════════════════════════════════════════

import network, urequests, ujson, time, machine
from machine import Pin, UART;

# ── Credenciales WiFi y Supabase ────────────────────────────────────
WIFI_SSID         = "ENTEL_HOGAR_2.4G"
WIFI_PASSWORD     = "123456789"
SUPABASE_URL      = "https://kjuoamogxpplpyaseeat.supabase.co"
SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtqdW9hbW9neHBwbHB5YXNlZWF0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzY3OTU1NDUsImV4cCI6MjA5MjM3MTU0NX0.ty8SNcnELPCKk43qoRJft4-8IVQz6GrSouoX4T188CQ"
TABLA_LECTURAS    = "lecturas_collar"   # tabla principal de datos
TABLA_COMANDOS    = "comandos"          # tabla de comandos desde el dashboard
INTERVALO_CICLO   = 10                  # segundos entre cada ciclo de lectura

# Pines del ESP32-C3 --------------------------------------------------
# GPS NEO-M8L  : UART1  TX→GPIO5  RX→GPIO4   @ 115200 baud
# PIR          : GPIO3  (detector de movimiento)
# Buzzer activo: GPIO7  (señal activa HIGH)
led        = Pin(8,  Pin.OUT)           # LED integrado (algunos C3 usan GPIO8)
buzzer     = Pin(7,  Pin.OUT)           # Buzzer activo 3.3 V
pir        = Pin(3,  Pin.IN)            # Sensor PIR de movimiento

# GPS NEO-M8L a 115200 baud (confirmado con u-center)
gps = UART(1, baudrate=115200, tx=5, rx=4)

# ── Variable global de sesión WiFi ──────────────────────────────────
wlan = network.WLAN(network.STA_IF)


# ════════════════════════════════════════════════════════════════════
#  UTILIDADES
# ════════════════════════════════════════════════════════════════════

def blink(n=1, ms=100):
    """Parpadea el LED n veces como indicador visual de estado."""
    for _ in range(n):
        led.value(1); time.sleep_ms(ms)
        led.value(0); time.sleep_ms(ms)


def activar_buzzer(segundos=2):
    """Activa el buzzer durante el tiempo indicado y luego lo apaga."""
    print(f"[BUZZER] Activando por {segundos}s")
    buzzer.value(1)
    time.sleep(segundos)
    buzzer.value(0)
    print("[BUZZER] Apagado")


# ════════════════════════════════════════════════════════════════════
#  CONECTIVIDAD WiFi
# ════════════════════════════════════════════════════════════════════

def conectar_wifi():
    """
    Conecta el ESP32-C3 a la red WiFi configurada.
    Reintenta hasta 15 veces (15 s) antes de retornar False.
    """
    wlan.active(True)
    if wlan.isconnected():
        return True

    print(f"[WiFi] Conectando a '{WIFI_SSID}'...")
    wlan.connect(WIFI_SSID, WIFI_PASSWORD)

    for intento in range(15):
        if wlan.isconnected():
            print("[WiFi] Conectado →", wlan.ifconfig()[0])
            blink(3)
            return True
        time.sleep(1)

    print("[WiFi] No se pudo conectar")
    return False


# ════════════════════════════════════════════════════════════════════
#  LECTURA DE SENSORES
# ════════════════════════════════════════════════════════════════════

def detectar_movimiento(duracion_ms=2000):
    """
    Monitorea el sensor PIR durante 'duracion_ms' milisegundos.
    Retorna 1 si detectó movimiento, 0 si no.
    """
    inicio = time.ticks_ms()
    mov = 0
    while time.ticks_diff(time.ticks_ms(), inicio) < duracion_ms:
        if pir.value():
            mov = 1
        time.sleep_ms(100)
    print(f"[PIR] Movimiento: {'Sí' if mov else 'No'}")
    return mov


def leer_temperatura():
    """
    Función desactivada (sensor DHT22 no instalado).
    Retorna None.
    """
    return None


def _convertir_coordenada(raw, direccion):
    """
    Convierte el formato NMEA (DDDMM.MMMMM) a decimal.
    Aplica signo negativo para Sur (S) y Oeste (W).
    """
    if not raw:
        return None
    # Longitud tiene 3 dígitos de grado, latitud solo 2
    g = int(raw[:3]) if len(raw) > 7 else int(raw[:2])
    m = float(raw[3:]) if len(raw) > 7 else float(raw[2:])
    decimal = g + m / 60.0
    if direccion in ("S", "W"):
        decimal = -decimal
    return round(decimal, 6)


def leer_gps(timeout_ms=8000):
    """
    Lee la trama GPRMC/GNRMC del GPS NEO-M8L.
    Retorna (latitud, longitud) como floats, o (None, None) si no hay fix.
    Timeout por defecto: 8 segundos.
    """
    inicio = time.ticks_ms()
    buf = b""

    while time.ticks_diff(time.ticks_ms(), inicio) < timeout_ms:
        if gps.any():
            buf += gps.read()
            # Procesa línea a línea
            while b"\n" in buf:
                linea, buf = buf.split(b"\n", 1)
                try:
                    txt = linea.decode().strip()
                    # Buscamos la trama RMC que contiene posición + estado
                    if txt.startswith("$GPRMC") or txt.startswith("$GNRMC"):
                        partes = txt.split(",")
                        if len(partes) > 6 and partes[2] == "A":   # 'A' = fix activo
                            lat = _convertir_coordenada(partes[3], partes[4])
                            lon = _convertir_coordenada(partes[5], partes[6])
                            print(f"[GPS] Fix OK → lat={lat}  lon={lon}")
                            return lat, lon
                except Exception:
                    pass
        time.sleep_ms(50)

    print("[GPS] Sin fix en el timeout")
    return None, None


# ════════════════════════════════════════════════════════════════════
#  COMUNICACIÓN CON SUPABASE
# ════════════════════════════════════════════════════════════════════

def _headers_supabase():
    """Cabeceras HTTP comunes para peticiones a Supabase."""
    return {
        "apikey":        SUPABASE_ANON_KEY,
        "Authorization": f"Bearer {SUPABASE_ANON_KEY}",
        "Content-Type":  "application/json"
    }


def enviar_lectura(temp, mov, lat, lon):
    """
    Inserta una lectura en la tabla 'lecturas_collar' de Supabase.
    Solo envía campos con valor (evita 400 si la BD no acepta null).
    """
    url  = f"{SUPABASE_URL}/rest/v1/{TABLA_LECTURAS}"
    data = {"movimiento": bool(mov)}
    if temp is not None:
        data["temperatura"] = temp
    if lat is not None:
        data["latitud"] = lat
    if lon is not None:
        data["longitud"] = lon
    try:
        r = urequests.post(url, headers=_headers_supabase(),
                           data=ujson.dumps(data))
        print(f"[HTTP] Lectura enviada → {r.status_code}")
        if r.status_code not in (200, 201):
            try:
                print(f"[HTTP] Detalle: {r.text}")
            except Exception:
                pass
        r.close()
        if r.status_code in (200, 201):
            blink(1)   # parpadeo de confirmación
    except Exception as e:
        print(f"[HTTP] Error al enviar lectura: {e}")


def consultar_comando_buzzer():
    """
    Consulta la tabla 'comandos' en Supabase buscando el comando
    más reciente no ejecutado.  Si existe, activa el buzzer y
    marca el comando como ejecutado.
    """
    url = (f"{SUPABASE_URL}/rest/v1/{TABLA_COMANDOS}"
           f"?ejecutado=eq.false&order=created_at.desc&limit=1")
    try:
        r = urequests.get(url, headers=_headers_supabase())
        datos = ujson.loads(r.text)
        r.close()

        if datos:                      # hay al menos un comando pendiente
            comando = datos[0]
            id_cmd  = comando.get("id")
            accion  = comando.get("accion", "")
            print(f"[CMD] Recibido: {accion} (id={id_cmd})")

            if accion == "buzzer_on":
                activar_buzzer(3)      # suena 3 segundos

            # Marcar como ejecutado para no repetirlo
            _marcar_ejecutado(id_cmd)

    except Exception as e:
        print(f"[CMD] Error al consultar comandos: {e}")


def _marcar_ejecutado(id_cmd):
    """Actualiza el campo 'ejecutado' a true para el comando dado."""
    url  = f"{SUPABASE_URL}/rest/v1/{TABLA_COMANDOS}?id=eq.{id_cmd}"
    hdrs = _headers_supabase()
    hdrs["Prefer"] = "return=minimal"
    try:
        r = urequests.patch(url, headers=hdrs,
                            data=ujson.dumps({"ejecutado": True}))
        r.close()
        print(f"[CMD] Comando {id_cmd} marcado como ejecutado")
    except Exception as e:
        print(f"[CMD] Error al marcar ejecutado: {e}")


# ════════════════════════════════════════════════════════════════════
#  BUCLE PRINCIPAL
# ════════════════════════════════════════════════════════════════════

def main():
    print("=" * 50)
    print("  PetFinder Smart Collar — Iniciando...")
    print("=" * 50)
    blink(3)

    # Intentar conectar a WiFi al arrancar
    conectar_wifi()

    while True:
        print("\n─── NUEVO CICLO ───────────────────────────")

        # 1. Leer todos los sensores
        mov  = detectar_movimiento(2000)
        temp = leer_temperatura()
        lat, lon = leer_gps(8000)

        print(f"[DATA] temp={temp}  mov={mov}  lat={lat}  lon={lon}")

        # 2. Reconectar WiFi si se cayó
        if not wlan.isconnected():
            print("[WiFi] Reconectando...")
            conectar_wifi()

        # 3. Enviar datos y procesar comandos desde el dashboard
        if wlan.isconnected():
            enviar_lectura(temp, mov, lat, lon)
            consultar_comando_buzzer()   # ← verifica si el usuario activó el buzzer

        # 4. Esperar antes del próximo ciclo
        time.sleep(INTERVALO_CICLO)


# ── Punto de entrada con manejo de errores críticos ─────────────────
try:
    main()
except Exception as e:
    print(f"[ERROR CRÍTICO] {e}")
    time.sleep(5)
    machine.reset()
    # reinicio automático ante fallos inesperados
